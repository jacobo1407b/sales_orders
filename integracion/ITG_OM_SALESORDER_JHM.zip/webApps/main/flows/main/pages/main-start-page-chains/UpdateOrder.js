define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class UpdateOrder extends ActionChain {

    /**
     * Actualizar tabla
     * @param {Object} context
     * @param {Object} params
     * @param {OrderType} params.order 
     */
    async run(context, { order }) {
      const { $page, $flow, $application } = context;

      await Actions.fireDataProviderEvent(context, {
        target: $page.variables.TABLE_ORDERS_ADP,
        update: {
          data: order,
        },
      });

      await Actions.fireDataProviderEvent(context, {
        target: $page.variables.TABLE_ORDERS_ADP,
        refresh: null,
      });
    }
  }

  return UpdateOrder;
});
