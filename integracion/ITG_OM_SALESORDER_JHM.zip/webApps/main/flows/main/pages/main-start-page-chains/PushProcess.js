define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class PushProcess extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application } = context;

      let tempData = $page.variables.TABLE_ORDERS_ADP.data;

      if ($page.variables.cientId) {

        const callRestOrdersGetAllOrdersResult = await Actions.callRest(context, {
          endpoint: 'Orders/GetAllOrders',
          uriParams: {
            client: $page.variables.cientId,
          },
        });

        tempData = callRestOrdersGetAllOrdersResult.body.data;
      }

      if (!$page.variables.cientId || $page.variables.cientId === "") {

        const generateClient = await $page.functions.generateClient();

        $page.variables.cientId = generateClient;
      }

      $page.variables.isLoading = true;

      const callRestUpdateOrderClientUpdateClientsOrderResult = await Actions.callRest(context, {
        endpoint: 'UpdateOrderClient/UpdateClientsOrder',
        body: $page.variables.TABLE_ORDERS_ADP.data,
        uriParams: {
          clientid: $page.variables.cientId,
        },
      });

      const callRestJobProcessExecuteProcessResult = await Actions.callRest(context, {
        endpoint: 'JobProcess/executeProcess',
        uriParams: {
          socketId: $page.variables.socketId,
        },
        body: {
          data: tempData,
          client: $page.variables.cientId
        },
      });

      await Actions.fireNotificationEvent(context, {
        summary: $application.translations.app._summary_f042,
        type: 'info',
        message: $application.translations.app._message,
      });
    }
  }

  return PushProcess;
});
