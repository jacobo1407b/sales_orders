define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class InputTextValueChangeChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.value 
     */
    async run(context, { value }) {
      const { $page, $flow, $application } = context;

      await Actions.resetVariables(context, {
        variables: [
          '$page.variables.TABLE_ORDERS_ADP',
        ],
      });

      const callRestOrdersGetAllOrdersResult = await Actions.callRest(context, {
        endpoint: 'Orders/GetAllOrders',
        uriParams: {
          client: value,
        },
      });

      $page.variables.TABLE_ORDERS_ADP.data = callRestOrdersGetAllOrdersResult.body.data ?? [];

      await Actions.fireDataProviderEvent(context, {
        refresh: null,
        target: $page.variables.TABLE_ORDERS_ADP,
      });
    }
  }

  return InputTextValueChangeChain;
});
