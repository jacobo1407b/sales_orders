define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ResetData extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application } = context;

      const callComponentMethodLoadingStartOpenResult = await Actions.callComponentMethod(context, {
        selector: '#loadingStart',
        method: 'open',
      });

      await Actions.resetVariables(context, {
        variables: [
          '$page.variables.cientId',
          '$page.variables.TABLE_ORDERS_ADP',
          '$page.variables.TABLE_LINES_ADP',
          '$page.variables.details',
        ],
      });

      const callFunctionResult = await $page.functions.delteClientId();

      const callRestOrdersGetAllOrdersResult = await Actions.callRest(context, {
        endpoint: 'Orders/GetAllOrders',
        uriParams: {
          client: "",
        },
      });

      $page.variables.TABLE_ORDERS_ADP.data = callRestOrdersGetAllOrdersResult.body.data ?? [];

      await Actions.fireDataProviderEvent(context, {
        target: $page.variables.TABLE_ORDERS_ADP,
        refresh: null,
      });

      const callComponentMethodLoadingStartCloseResult = await Actions.callComponentMethod(context, {
        selector: '#loadingStart',
        method: 'close',
      });
    }
  }

  return ResetData;
});
