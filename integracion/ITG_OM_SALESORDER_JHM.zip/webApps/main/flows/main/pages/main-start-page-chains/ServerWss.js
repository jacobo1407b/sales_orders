define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
  'https://cdn.socket.io/4.7.4/socket.io.min.js'
], (
  ActionChain,
  Actions,
  ActionUtils,
  io
) => {
  'use strict';

  class ServerWss extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application } = context;
      const socket = io(`wss://${$page.variables.hostWss}`, { transports: ['websocket'] });

      socket.on("connect", () => {
        $page.variables.socketId = socket.id;
      });
      socket.on("message", async (msg) => {
        const callChainUpdateOrderResult = await Actions.callChain(context, {
          chain: 'UpdateOrder',
          params: {
            order: msg,
          },
        });
      });

      socket.on("loading", async (msg) => {
        let data = msg.loading;
        $page.variables.isLoading = data;
      });
    }
  }

  return ServerWss;
});
