define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class DownloadAction extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.key 
     * @param {number} params.index 
     * @param {any} params.current 
     */
    async run(context, { key, index, current }) {
      const { $page, $flow, $application } = context;

      const callRestOrdersDownloadFileResult = await Actions.callRest(context, {
        endpoint: 'Orders/DownloadFile',
        uriParams: {
          load: current.data.IdLoad,
        },
        responseBodyFormat: 'blob',
      });

      const callFunctionResult = await $page.functions.downloadBlob(callRestOrdersDownloadFileResult.body, current.data.FileError ? current.data.FileError : current.data.IdLoad + ".log");

      await Actions.fireNotificationEvent(context, {
        summary: $application.translations.app._summary,
        type: 'info',
      });
      
    }
  }

  return DownloadAction;
});
