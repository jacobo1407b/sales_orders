define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class GetServerSideProps extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application } = context;

      const getClient = await $page.functions.getClientId();

      $page.variables.cientId = getClient;

      const runInParallelResult = await Promise.all([
        async () => {

          const callRestOrdersGetAllOrdersResult = await Actions.callRest(context, {
            endpoint: 'Orders/GetAllOrders',
            uriParams: {
              client: $page.functions.getClientId(),
            },
          });

          $page.variables.TABLE_ORDERS_ADP.data = callRestOrdersGetAllOrdersResult.body?.data ? callRestOrdersGetAllOrdersResult.body?.data  : [];

          await Actions.fireDataProviderEvent(context, {
            target: $page.variables.TABLE_ORDERS_ADP,
            refresh: null,
          });
        },
        async () => {

          const callRestGetLookupGetLooupResult = await Actions.callRest(context, {
            endpoint: 'getLookup/getLooup',
            uriParams: {
              name: 'SCM_OM_STATUSES',
            },
            responseBodyFormat: 'blob',
          });

          const callFunctionResultLookup = await $page.functions.convertLookup(callRestGetLookupGetLooupResult.body);

          $page.variables.statusData = callFunctionResultLookup;
        },
        async () => {

        const callRestBusinessObjectsGetallUOMResult = await Actions.callRest(context, {
          endpoint: 'businessObjects/getall_UOM',
          uriParams: {
            limit: 500,
          },
        });

          $page.variables.arrayUoms = callRestBusinessObjectsGetallUOMResult.body.items;


        }
      ].map(sequence => sequence()));

      const callChainServerWssResult = await Actions.callChain(context, {
        chain: 'ServerWss',
      });

      const callComponentMethodLoadingStartCloseResult = await Actions.callComponentMethod(context, {
        selector: '#loadingStart',
        method: 'close',
      });
    }
  }

  return GetServerSideProps;
});
