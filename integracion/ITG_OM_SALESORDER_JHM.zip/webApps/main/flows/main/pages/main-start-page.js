define([], () => {
  'use strict';

  class PageModule {
    getClientId() {
      let ke = localStorage.getItem("client") ?? "";
      return ke;
    }
    delteClientId() {
      localStorage.removeItem("client");
    }
    setClientId(id) {
      return localStorage.setItem("client", id);
    }

    async convertLookup(data) {
      let file = new File([data], "lookup.txt");
      let prom = new Promise((resolve, reject) => {
        try {
          let reader = new FileReader();
          reader.onload = function () {
            let text = reader.result;
            const dataStatus = [];
            const split = text.split("\n");
            for (let i = 2; i < split.length - 1; i++) {
              const element = split[i].split(",");
              dataStatus.push({
                code: element[1],
                meaning: element[2]
              });
            }
            resolve(dataStatus);
          };
          reader.readAsText(file);
        } catch (error) {
          console.log(error);
          resolve([]);
        }
      });
      const dataLookup = await prom;
      return dataLookup;
    }

    searchStatus(arrStatus, code) {
      let status = arrStatus.filter((x) => x.code === code);
      if (status.length === 0) {
        return code;
      } else {
        return status[0].meaning;
      }
    }

    generateClient() {
      let hash = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
        let r = Math.random() * 16 | 0, v = c === 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
      });
      this.setClientId(hash);
      return hash;
    }

    downloadBlob(blob, name) {
      // Convert your blob into a Blob URL (a special url that points to an object in the browser's memory)
      const blobUrl = URL.createObjectURL(blob);

      // Create a link element
      const link = document.createElement("a");

      // Set link's href to point to the Blob URL
      link.href = blobUrl;
      link.download = name;

      // Append link to the body
      document.body.appendChild(link);

      // Dispatch click event on the link
      // This is necessary as link.click() does not work on the latest firefox
      link.dispatchEvent(
        new MouseEvent('click', {
          bubbles: true,
          cancelable: true,
          view: window
        })
      );

      // Remove link from body
      document.body.removeChild(link);
    }

    findCodeUom(arr, code) {
      let filt = arr.filter((x) => x.uOMCode === code);
      if (filt.length === 0) {
        return code;
      } else {
        return filt[0].uOM;
      }
    }
  }

  return PageModule;
});
